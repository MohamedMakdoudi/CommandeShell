package com.redlean.ssh;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SSHManager {

	private static String USERNAME = "makdoudi"; // username for remote host
	private static String PASSWORD = "kom"; // password of the remote host
	private static String HOST = "localhost"; // remote host address
	private static int PORT = 22;

	public static List<String> executeCommande(String scriptFileName) {
		List<String> result = new ArrayList<String>();
		try {

			/**
			 * Create a new Jsch object
			 * This object will execute shell commands or scripts on server
			 */
			JSch jsch = new JSch();

			/*
			 * Ouvrir une nouvelle session, avec votre nom d'utilisateur, hôte et port
			 * Définir le mot de passe et appeler connecter.
			 * session.connect () ouvre une nouvelle connexion au serveur SSH distant.
			 * Une fois la connexion établie, vous pouvez lancer une nouvelle chaîne.
			 */

			Session session = jsch.getSession(USERNAME, HOST, PORT);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(PASSWORD);
			session.connect();

			// créer le canal d'exécution
			ChannelExec channelExec = (ChannelExec) session.openChannel("exec");

			// Obtient un InputStream pour ce canal
			InputStream in = channelExec.getInputStream();

			// Définir la commande que vous voulez exécuter
			channelExec.setCommand(scriptFileName);

			// Exécuter la commande
			channelExec.connect();

			// Lire la sortie du flux d'entrée
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			String line;

			// Lisez chaque ligne du lecteur tamponné et ajoutez-la à la liste des résultats
			while ((line = reader.readLine()) != null) {
				result.add(line);
			}

			// récupérer le statut de sortie de la commande à distance
			int exitStatus = channelExec.getExitStatus();

			// Déconnectez en toute sécurité le canal et déconnectez la session.
			channelExec.disconnect();
			session.disconnect();

			if (exitStatus < 0) {
				// Terminé, mais le statut de sortie n'est pas défini
			} else if (exitStatus > 0) {
				// Fait, mais avec erreur!
			} else {
				// Fait
			}

		} catch (Exception e) {
			System.err.println("Error: " + e);
		}
		return result;
	}

}