package com.redlean.socket;

import java.io.IOException;
import java.util.List;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import com.redlean.ssh.SSHManager;

@ServerEndpoint("/websocket")
public class WebSocket {

	@OnMessage
	public void onMessage(String message, Session session) throws IOException, InterruptedException {

		// afficher le messge de client
		System.out.println("Received: " + message);

		// execution de la commande
		List<String> res = SSHManager.executeCommande(message);
		String msg = "";
		for (int i = 0; i < res.size(); i++) {
			msg += res.get(i) + ",";
		}

		// envoyer le message au client
		session.getBasicRemote().sendText(msg);

		// fermer la connexion
		onClose();
	}

	@OnOpen
	public void onOpen() {
		System.out.println("Client connected");
	}

	@OnClose
	public void onClose() {
		System.out.println("Connection closed");
	}

}